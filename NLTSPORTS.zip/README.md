# NLTSPORTS

Next.js 14 (App Router) + TailwindCSS.

Routes:
- `/` Landing
- `/apply` Application
- `/owner` Owner portal (demo)

## Run
```bash
npm install
npm run dev
```

## Cloudflare Pages
- Framework: Next.js
- Build: `npm run build`
- Output: `.next`
